package Ejercicios_1_al_10;

import java.util.Scanner;

public class RaizCuadrada {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		int a;
		double b;
		
		System.out.println("Ingrese el valor sub-indice");
		a = tc.nextInt();
		
		if (a <= -1) {
			System.out.println("No se admiten valores menores a cero");
		}else {
			b = Math.sqrt(a);
			
			System.out.println("La raiz cuadrada de " +a+ " es: " +b);
		}
		
	}

}
