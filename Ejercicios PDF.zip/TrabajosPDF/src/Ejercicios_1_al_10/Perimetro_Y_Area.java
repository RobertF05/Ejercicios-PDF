package Ejercicios_1_al_10;

import java.util.Scanner;

public class Perimetro_Y_Area {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		double p, a;
		int r, d;
		
		System.out.println("Ingrese el Diametro:");
		d = tc.nextInt();
		
		if (d <= 0) {
			System.out.println("El circulo no existe");
		}else {
			p = 3.141592654 * d;
			r = d/2;
			a = 3.141592654 * (r * r);
			
			System.out.println("El Perimetro es: " +p);
			System.out.println("El Area es: " +a);
		}

	}

}
