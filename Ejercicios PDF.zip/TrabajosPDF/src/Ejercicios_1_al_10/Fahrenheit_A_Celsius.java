package Ejercicios_1_al_10;

import java.util.Scanner;

public class Fahrenheit_A_Celsius {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		int f;
		double c;
		System.out.println("Ingrese grados en Fahrenheit: ");
		f = tc.nextInt();
		
		c = (f - 32) * 5/9;
		
		System.out.println("Su valor en grados Celsius es: " +c);

	}

}
