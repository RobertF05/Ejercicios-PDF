package Ejercicios_1_al_10;

import java.util.Scanner;

public class N_Kilogramos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		double k, l;
		
		System.out.println("Ingrese un valor en Kilogramos");
		k = tc.nextDouble();
		
		if (k <= -1) {
			System.out.println("No se admiten numeros negativos");
		}else {
			l = k * 2.2;
			
			System.out.println("Su valor en Libras es: " +l);
		}
	}

}
