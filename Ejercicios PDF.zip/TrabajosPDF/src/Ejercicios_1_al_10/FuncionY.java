package Ejercicios_1_al_10;

import java.util.Scanner;

public class FuncionY {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Evaluar la Función Y= 5X^4 + 2X^3 + 3X^2 + 7 para el valor de 
		a) X=1;
		b) X un número cualquiera*/
		Scanner tc = new Scanner(System.in);
		int x1 = 1, x2 = 0, y1, y2;
		
		System.out.println("Ingrese el valor de X: ");
		x2 = tc.nextInt();
		
		y1 = (int) (5 * Math.pow(x1, 4) + 2 * Math.pow(x1, 3) + 7);
		y2 = (int) (5 * (Math.pow(x2, 4)) + 2 * (Math.pow(x2, 3)) +3 * (Math.pow(x2, 2))  + 7);
		
		System.out.println("El resultado del inciso a es: " +y1);
		System.out.println("El resultado del inciso b es: " +y2);

	}

}
