package Ejercicios_1_al_10;

import java.util.Scanner;

public class Area_Triangulos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		int a, b = 0, c = 0;
		double s, S, A;
		
		System.out.println("Ingrese el 1er lado: ");
		a = tc.nextInt();
		if (a <= 0) {
			System.out.println("Valor invalido");
		}else {
			System.out.println("Ingrese el 2do lado: ");
			b = tc.nextInt();
		}
		if (b <= 0) {
			System.out.println("Valor invalido");
		}else {
			System.out.println("Ingrese el 3er lado: ");
			c = tc.nextInt();
		}
		if (c <= 0) {
			System.out.println("Valor invalido");
		}else {
			
			s = (double) (a + b + c)/2;
			S = (double)s * (s - a)*(s - b)*(s - c);
			A = Math.sqrt(S);
			
			System.out.println("El area del triangulo es: " +A);
		}

	}

}
