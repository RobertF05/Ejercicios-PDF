package Ejercicios_1_al_10;

import java.util.Scanner;

public class Valor_Fuerza {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		int f, m, a;
		
		System.out.println("Ingrese valor de Masa: ");
		m = tc.nextInt();
		do {
			System.out.println("Valor invalido");
			System.out.println("Ingrese valor de Masa: ");
			m = tc.nextInt();
		}while(m <= 0);
		
		do {
			System.out.println("Ingrese valor de Aceleracion: ");
			a = tc.nextInt();
		}while(a <= -1);
		if (m >= 1 && a >= 0) {
			f = m*a;
			
			System.out.println("El valor de Fuerza es: " +f);
		}
		}

	}


