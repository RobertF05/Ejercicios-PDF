package Ejercicios_1_al_10;

import java.util.Scanner;

public class Volumen_Cilindro {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		int r, h = 0;
		double v;
		
		System.out.println("Ingrese el Radio: ");
		r = tc.nextInt();
		if(r <= 0) {
			System.out.println("Valor invalido");
		}else {
			System.out.println("Ingrese la Altura: ");
			h = tc.nextInt();
		}if (h <= 0) {
			System.out.println("Valor invalido");
		}else {
			v = Math.PI * Math.pow(r, 2) * h;
			
			System.out.println("El Volumen es: " +v);
		}
		
	}

}
