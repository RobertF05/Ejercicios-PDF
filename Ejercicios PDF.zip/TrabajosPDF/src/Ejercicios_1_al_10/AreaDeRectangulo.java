package Ejercicios_1_al_10;

import java.util.Scanner;

public class AreaDeRectangulo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		int b, h, a= 0;
		
		System.out.println("Ingrese la Base: ");
		b = tc.nextInt();
		System.out.println("Ingrese la Altura: ");
		h = tc.nextInt();
		
		if (b <= 0 || h <= 0 ) {
			System.out.println("El rectangulo no existe");
		}else {
			a  = b*h;
			
			System.out.println("La Base es: " +b);
			System.out.println("La Altura es: " +h);
			System.out.println("El Area es: " +a);
		}
	}

}
