package Ejercicios_1_al_10;

import java.util.Scanner;

public class ValorY {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Determine el valor de Y= X*C-2 donde C es una constante con valor C=2.5.
		a) Sabiendo que X=2;
		b) Considerando a X un valor cualquiera*/
		Scanner tc = new Scanner(System.in);
		int x1 = 2, x2 = 0;
		double c = 2.5, y1, y2;
		
		System.out.println("Ingrese valor de X");
		x2 = tc.nextInt();
		
		y1 = x1 * c-2;
		y2 = x2 * c-2;
		
		System.out.println("En el inciso a el resultado es: " +y1);
		System.out.println("En el inciso b el resultado es: " +y2);
	}

}
