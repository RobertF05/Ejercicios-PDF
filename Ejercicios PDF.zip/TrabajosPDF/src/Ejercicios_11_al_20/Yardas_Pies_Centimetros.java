package Ejercicios_11_al_20;

import java.util.Scanner;

public class Yardas_Pies_Centimetros {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		double y1, y2, f1, c, i1, f2, i2;
		
		System.out.println("Introduzca Valor en Yardas: ");
		y1 = tc.nextDouble();
		System.out.println("Introduzca Valor en Pies: ");
		f1 = tc.nextDouble();
		System.out.println("Introduzca Valor en Pulgadas : ");
		i1 = tc.nextDouble();
		
		f2 = y1 * 0.333333;
		i2 = y1 * 0.0277778;
		y2 = y1 + f2 + i2;
		c = y2 * 91.44;
		
		System.out.println("Su Valor en Centimetros es: " +c);

	}

}
