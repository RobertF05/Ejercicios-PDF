package Ejercicios_11_al_20;

import java.util.Scanner;

public class TresCifras2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		int a1, a2 = 0 , a3 = 0, b;
		
		System.out.println("Invertir un Numero de 3 Cifras");
		System.out.println("Ingrese la Primer cifra: ");
		a1 = tc.nextInt();
		
		do {
			System.out.println("Ingrese Solo Numeros del 0 al 9");
			System.out.println("Ingrese la Primer cifra: ");
			a1 = tc.nextInt();
		}while (a1 <= -1 || a1 >= 10);
		System.out.println("Ingrese la Segunda cifra: ");
		a2 = tc.nextInt();
		
		do {
			System.out.println("Ingrese Solo Numeros del 0 al 9");
			System.out.println("Ingrese la Segunda cifra: ");
			a2 = tc.nextInt();
		}while (a2 <= -1 || a2 >= 10) ;
		System.out.println("Ingrese la Tercer cifra: ");
		a3 = tc.nextInt();
		
		do {
			System.out.println("Ingrese Solo Numeros del 1 al 9");
			System.out.println("Ingrese la Tercer cifra: ");
			a3 = tc.nextInt();
		}while (a3 <= 0 || a3 >= 10) ;
			System.out.println("El valor Ingresado es: " +a3+a2+a1);
			System.out.println("El valor Invertido es: " +a1+a2+a3);

	}

}
