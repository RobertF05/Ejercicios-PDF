package Ejercicios_11_al_20;

import java.util.Scanner;

public class Cramer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		double a, b, c, d, e, f, det, x, y;
		
		System.out.println("Sistema de Ecuacion Lineal:");
		System.out.println("ax + by = c");
		System.out.println("dx + ey = f");
		System.out.println("Ingrese el Valor de [a]");
		a = tc.nextDouble();
		System.out.println("Ingrese el Valor de [b]");
		b = tc.nextDouble();
		System.out.println("Ingrese el Valor de [c]");
		c = tc.nextDouble();
		System.out.println("Ingrese el Valor de [d]");
		d = tc.nextDouble();
		System.out.println("Ingrese el Valor de [e]");
		e = tc.nextDouble();
		System.out.println("Ingrese el Valor de [f]");
		f = tc.nextDouble();
		
		det = a * e - b * d;
		if(det == 0){
			System.out.println("No hay una Solucion Unica");
		}else {
			x = (c * e - b * f)/det;
			y = (a * f - c * d)/det;
			System.out.println("La Solucion es: ");
			System.out.println("x = " +x);
			System.out.println("y = " +y);
			System.out.println("El Sistema de Ecuaciones Lineales Queda: ");
			System.out.println(a+"(" +x+") + "+b+"("+y+") = "+c);
			System.out.println(d+"(" +x+") + "+e+"("+y+") = "+f);
		}

	}

}
