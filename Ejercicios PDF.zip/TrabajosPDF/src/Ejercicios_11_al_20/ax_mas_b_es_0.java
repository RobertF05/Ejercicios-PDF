package Ejercicios_11_al_20;

import java.util.Scanner;

public class ax_mas_b_es_0 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		Double a, b, x, p1;
		
		System.out.println("Introduzca Valor de [a]: ");
		a = tc.nextDouble();
		System.out.println("Introduzca valor de [b]: ");
		b = tc.nextDouble();
		
		p1 = b * (-1);
		x = p1 / a;
		
		System.out.println("El valor de [x] en la ecuacion " +a+"x + " +b+ " = 0 es: " + x);
		
	}

}
