package Ejercicios_11_al_20;

import java.util.Scanner;

public class N_notas {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		double notas = 0, suma = 0, prom;
		int n;
		
		System.out.println("¿Cuantas notas desea Ingresar?");
		n = tc.nextInt();
		
		for(int i = 1; i <= n; i++ ) {
		System.out.println("Ingrese la nota #" +i+ " :");
		notas = tc.nextDouble();
		suma += notas;
		}
		
		prom = suma/n;
		
		System.out.println("El promedio de las notas es: " +prom);

	}

}
