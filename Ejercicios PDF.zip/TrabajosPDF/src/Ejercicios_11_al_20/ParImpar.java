package Ejercicios_11_al_20;

import java.util.Scanner;

public class ParImpar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc= new Scanner(System.in);
		int num = 0;
		
		System.out.println("Ingrese un numero");
		num= tc.nextInt();
		if (num%2==0) {
			System.out.println("El numero ingresado es par");
		}
		else {
			System.out.println("El numero ingresado es impar");
		}

	}

}
