package Ejercicios_11_al_20;

import java.util.Scanner;

public class Votante {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		int edad = 0;
		try {
		System.out.println("Ingrese su Edad: ");
		edad = tc.nextInt();
		
		do {
			System.out.println("No son Validos los Negativos");
			System.out.println("Ingrese su Edad: ");
			edad = tc.nextInt();
		}while(edad <= -1);
		
		if (edad <= 15) {
			System.out.println("Usted no puede votar ya que es menor de 16 años");
		}else {
			System.out.println("Usted puede votar ya tiene 16 o mas años");
		}
		}catch (Exception e) {
			if (edad <= 15) {
				System.out.println("Usted no puede votar ya que es menor de 16 años");
			}else {
				System.out.println("Usted puede votar ya tiene 16 o mas años");
		}
	}
	}
}

