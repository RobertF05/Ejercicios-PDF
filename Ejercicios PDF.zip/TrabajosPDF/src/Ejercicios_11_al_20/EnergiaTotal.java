package Ejercicios_11_al_20;

import java.util.Scanner;

public class EnergiaTotal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		double et, ec, ep, m, v, h;
		
		System.out.println("Ingrese un Valor de Masa: ");
		m = tc.nextDouble();
		System.out.println("Ingrese la Velocidad: ");
		v = tc.nextDouble();
		System.out.println("Ingrese su Altura: ");
		h = tc.nextDouble();
		
		ec = (double) (m * (v*v))/2;
		ep = m * h * 9.8;
		et = ec + ep;
		
		System.out.println("La Energia Cinetica es: " +ec);
		System.out.println("La Energia Potencial es: " +ep);
		System.out.println("La Energia Total es: " +et);

	}

}
