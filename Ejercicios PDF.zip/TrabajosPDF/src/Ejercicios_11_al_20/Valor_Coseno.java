package Ejercicios_11_al_20;

import java.util.Scanner;
import java.lang.Math;

public class Valor_Coseno {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		double a, b;
		
		System.out.println("Ingrese un valor: ");
		a = tc.nextDouble();
		
		b = Math.cos(a) ;
		
		System.out.println("El Coseno de " +a+ " es: " +b);

	}

}
