package Ejercicios_50_al_62;

public class Tres_numeros_Perfectos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int count = 0, n = 2;
		while(count < 3) {
			int suma = 1;
			for(int i = 2; i <= n/2; i++) {
				if(n % i == 0) {
					suma = suma + i;
				}
			}
			if(suma == n) {
				System.out.println("Numero Perfecto #"+(count+1)+": "+n);
				count++;
			}
			n++;
		}

	}

}
