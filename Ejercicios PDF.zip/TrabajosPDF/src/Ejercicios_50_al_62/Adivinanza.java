package Ejercicios_50_al_62;

import java.util.Scanner;

public class Adivinanza {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		int count = 0;
		
		while(count < 3) {
			System.out.println("¿Cual es la Capital del Folclore Nicaraguense?");
			System.out.println("A: Managua");
			System.out.println("B: Masaya");
			System.out.println("C: Granada");
			String tcv = tc.nextLine();
			String May =  tcv.toUpperCase();
			if(May.equals("B")) {
				System.out.println("Respuesta Correcta");
				return;
			}else {
				count = count + 1;
				System.out.println("Respuesta Incorrecta");
			}
			
		}
		System.out.println("Demasiados intentos fallidos");
		System.out.println("La Respuesta Correcta era: B: Masaya");
		}

	private static void toUpperCase() {
		
	}

}
