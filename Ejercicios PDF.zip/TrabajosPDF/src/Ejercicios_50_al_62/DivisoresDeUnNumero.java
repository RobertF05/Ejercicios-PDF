package Ejercicios_50_al_62;

import java.util.Scanner;

public class DivisoresDeUnNumero {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		int n;
		
		System.out.println("Ingrese Un Numero: ");
		n = tc.nextInt();
		
		System.out.println("Los Divisores de " +n+ " son: ");
		for(int i = 1; i <= n; i++) {
			if(n % i == 0) {
				System.out.println(i);
			}
		}

	}

}
