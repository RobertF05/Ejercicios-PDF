package Ejercicios_50_al_62;

import java.util.Scanner;

public class Numeros_Perfectos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		int n, div = 0;
		System.out.println("Ingrese Un Numero: ");
		n = tc.nextInt();
		
		//System.out.println("Los Divisores de " +n+ " son: ");
		for(int i = 1; i < n; i++) {
			if(n % i == 0) {
				//System.out.println(i);
				div = div + i;
			}
		}
		
		if(div == n) {
			System.out.println(n+ " Es un Numero Perfecto");
		}else {
			System.out.println(n+ " No es un Numero Perfecto");
		}

	}

}
