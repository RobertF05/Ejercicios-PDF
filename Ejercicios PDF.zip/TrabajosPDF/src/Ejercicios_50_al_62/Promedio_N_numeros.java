package Ejercicios_50_al_62;

import java.util.Scanner;

public class Promedio_N_numeros {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		int n, v, suma = 0;
		double prom;
		
		System.out.println("¿Cuantos Valores va a Ingresar?");
		n = tc.nextInt();
		
		for(int i = 1; i <= n; i++) {
			System.out.println("Ingrese el Valor #" +i);
			v = tc.nextInt();
			suma = suma + v;
		}
		
		prom = (double) suma / n;
		System.out.println("El Promedio es: " +prom);

	}

}
