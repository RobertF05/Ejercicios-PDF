package Ejercicios_50_al_62;

import java.util.Scanner;

public class Pos_Neg_Cero {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		int pos = 0, neg = 0, cero = 0, n;
		
		for(int i = 1; i <= 20; i++) {
			System.out.println("Ingrese Valor #" +i);
			n = tc.nextInt();
			if(n <= -1) {
				neg = neg + 1;
			}else if(n >= 1) {
				pos = pos + 1;
			}else if(n == 0) {
				cero = cero + 1;
			}
		}
		
		System.out.println("La Cantidad de Positivos es: " +pos);
		System.out.println("La Cantidad de Negativos es: " +neg);
		System.out.println("La Cantidad de Ceros es: " +cero);

	}

}
