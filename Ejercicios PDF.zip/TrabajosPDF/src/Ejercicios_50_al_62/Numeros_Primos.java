package Ejercicios_50_al_62;

import java.util.Scanner;

public class Numeros_Primos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		int n;
		
		System.out.println("Ingrese un Numero: ");
		n = tc.nextInt();
		boolean primo = true;
		
		if(n <= 1) {
			primo = false;
		}else {
			for(int i = 2; i <= Math.sqrt(n); i++) {
				if(n % i == 0) {
					primo = false;
					break;
				}
			}
		}
		if(primo) {
			System.out.println(n+ " Es Primo");
		}else {
			System.out.println(n+ " No es Primo");
		}

	}

}
