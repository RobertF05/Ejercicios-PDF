package Ejercicios_50_al_62;

import java.util.Scanner;

public class Fibonacci {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		int a = 0, b = 1, c;
		
		System.out.println("Primeros 20 Valores de la Serie Fibonacci: ");
		System.out.println("Fibonacci #1: " +a);
		System.out.println("Fibonacci #2: " +b);
		
		for(int i = 3; i <= 20; i++ ) {
			c = a + b;
			System.out.println("Fibonacci #" +i+ ": " +c);
			a = b;
			b = c;
		}

	}

}
