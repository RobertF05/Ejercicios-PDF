package Ejercicios_50_al_62;

import java.util.Scanner;

public class Suma_Pares_Impares {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		int par = 0, impar = 0, n;
		
		for(int i = 1; i <= 20; i++) {
			System.out.println("Ingrese Valor #" +i);
			n = tc.nextInt();
			if(n % 2 == 0) {
				par = par + n;
			}else if(n % 2 != 0) {
				impar = impar + n;
			}
		}
		
		System.out.println("La Suma de los Pares es: " +par);
		System.out.println("La Suma de los Impares es: " +impar);
		


	}

}
