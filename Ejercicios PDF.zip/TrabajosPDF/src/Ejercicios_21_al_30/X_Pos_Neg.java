package Ejercicios_21_al_30;

import java.util.Scanner;

public class X_Pos_Neg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		int x, r;
		
		System.out.println("Ingrese un Valor: ");
		x = tc.nextInt();
		
		if(x <= -1) {
			r = x*x*x*x;
			System.out.println("El Valor es Negativo por lo que el resultado es: " +r);
		}else {
			r = x*x;
			System.out.println("El Valor es Positivo por lo que el resultado es: " +r);
		}

	}

}
