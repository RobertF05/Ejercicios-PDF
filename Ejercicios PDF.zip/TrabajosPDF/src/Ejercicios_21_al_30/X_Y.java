package Ejercicios_21_al_30;

import java.util.Scanner;

public class X_Y {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		int x, y;
		double z;
		
		System.out.println("Ingrese el Primer Valor");
		x = tc.nextInt();
		System.out.println("Ingrese el Segundo Valor");
		y = tc.nextInt();
		
		if(x < 0 && y < 0) {
			z = (int) ((Math.pow(x, 2))+(Math.pow(y, 2)));
			System.out.println("Su resultado es: ["+z+"]");
		}else if(x < 0 && y >= 0){
			z = y - x;
			System.out.println("Su resultado es: ["+z+"]");
		}else if(x >= 0 && y < 0){
				z = x / y;
				System.out.println("Su resultado es: ["+z+"]");
		}else if(x >= 0 && y >= 0){
			if(x > y) {
				z = x + y;
				System.out.println("Su resultado es: ["+z+"]");
			}else {
				z = (double) Math.sqrt(x);
				System.out.println("Su resultado es: ["+z+"]");
			}
		}
	}
}