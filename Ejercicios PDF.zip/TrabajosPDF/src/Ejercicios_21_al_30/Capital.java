package Ejercicios_21_al_30;

import java.util.Scanner;

public class Capital {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		double cap, i, ir;
		
		System.out.println("Ingrese el Capital: ");
		cap = tc.nextDouble();
		
		if(cap <= 10000) {
			i = (double) cap * 0.06;
			ir = (double) cap - i;
			System.out.println("Capital Ingresado: " +cap);
			System.out.println("Interes Aplicado: 6%");
			System.out.println("Capital Restado: " + i);
			System.out.println("Capital Final: " +ir);
		}else {
			i = (double) cap * 0.07;
			ir = (double) cap - i;
			System.out.println("Capital Ingresado: " +cap);
			System.out.println("Interes Aplicado: 7%");
			System.out.println("Capital Restado: " + i);
			System.out.println("Capital Final: " +ir);
		}

	}

}
