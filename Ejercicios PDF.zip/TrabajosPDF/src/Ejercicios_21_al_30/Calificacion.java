package Ejercicios_21_al_30;

import java.util.Scanner;

public class Calificacion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		double cal;
		
		System.out.println("Ingrese la nota: ");
		cal = tc.nextDouble();
		
		while(cal <= -1 || cal >= 101) {
			System.out.println("Solo son Validos los Valores del 0 al 100");
			System.out.println("Ingrese la nota: ");
			cal = tc.nextDouble();
		}
		
		if(cal <= 59) {
			System.out.println("Esta Reprobado");
		}else {
			System.out.println("Esta Aprobado");
		}

	}

}
