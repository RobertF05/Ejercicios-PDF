package Ejercicios_21_al_30;

import java.util.Scanner;

public class Signos_Opuestos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		int a, b, aa, bb;
		
		System.out.println("Ingrese el Primer Valor");
		a = tc.nextInt();
		System.out.println("Ingrese el Segundo Valor");
		b = tc.nextInt();
		
		if(a < 0 && b > 0 || a > 0 && b < 0 || a == 0 && b < 0 || a < 0 && b == 0) {
			a = a * (-1);
			b = b * (-1);
			System.out.println("Su resultado es: ["+a+"] y ["+b+"]");
		}else {
			System.out.println("Su resultado es: ["+a+"] y ["+b+"]");
		}

	}

}
