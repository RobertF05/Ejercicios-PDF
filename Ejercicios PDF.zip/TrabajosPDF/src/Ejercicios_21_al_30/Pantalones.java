package Ejercicios_21_al_30;

import java.util.Scanner;

public class Pantalones {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		int n, p;
		
		System.out.println("¿Cuantos Pantalones Desea Comprar?");
		n = tc.nextInt();
		
		if(n >= 4) {
			p = n * 10;
			System.out.println("Ha Comprado " +n+ " Pantalones");
			System.out.println("Su Costo Total es: " +p);
		}else {
			p = n * 12;
			System.out.println("Ha Comprado " +n+ " Pantalones");
			System.out.println("Su Costo Total es: " +p);
		}

	}

}
