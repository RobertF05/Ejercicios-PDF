package Ejercicios_21_al_30;

import java.util.Scanner;

public class Divisible_Entre_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		int a;
		
		System.out.println("Ingrese un valor");
		a = tc.nextInt();
		
		if(a%3 == 0) {
			System.out.println("Es Divisible Entre 3");
		}else {
			System.out.println("No es Divisible Entre 3");
		}

	}

}
