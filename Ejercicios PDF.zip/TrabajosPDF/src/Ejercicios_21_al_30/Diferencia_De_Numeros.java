package Ejercicios_21_al_30;

import java.util.Scanner;

public class Diferencia_De_Numeros {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc  = new Scanner(System.in);
		int a, b, c;
		
		System.out.println("Ingrese el Primer Valor: ");
		a = tc.nextInt();
		System.out.println("Ingrese el Segundo Valor: ");
		b = tc.nextInt();
		
		if (a < b) {
			c = b - a;
		}else {
			c = a - b;
		}
		System.out.println("La Diferencia Entre " +a+ " y " +b+ " es: " +c);

	}

}
