package Ejercicios_41_al_45;

import java.util.Scanner;

public class N_Voltajes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		double voltaje, voltaje2 = 0, min = 0, max = 0, prom, n, suma = 0, sumaprom = 0;
		
		System.out.println("¿Cuantos Voltajes va a Ingresar?");
		n = tc.nextDouble();
		
		max = Integer.MIN_VALUE;
		min = Integer.MAX_VALUE;
		
		for(int i = 1; i <= n; i++) {
			System.out.println("Ingrese Voltaje #" +i);
			voltaje = tc.nextDouble();
			sumaprom = sumaprom + voltaje;
			if(voltaje > max) {
				max = voltaje;
			}
			if (voltaje < min){
				min = voltaje;
			}
		}
		prom = sumaprom / n;
		System.out.println("El Maximo Voltaje es: " +max);
		System.out.println("El Minimo Voltaje es: " +min);
		System.out.println("El Promedio es: " +prom);

	}
	
}
