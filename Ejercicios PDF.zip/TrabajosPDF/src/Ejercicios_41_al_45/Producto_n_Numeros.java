package Ejercicios_41_al_45;

import java.util.Scanner;

public class Producto_n_Numeros {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		int n, v, producto = 1;
		
		System.out.println("Ingrese la Cantidad de numeros a Multiplicar: ");
		n = tc.nextInt();
		
		for(int i = 1; i <= n; i++) {
			System.out.println("Ingrese Numero #" +i);
			v = tc.nextInt();
			producto = producto * v;
		}
		System.out.println("EL producto Total es: " +producto);

	}

}
