package Ejercicios_41_al_45;

import java.util.Scanner;

public class Niño_Joven_Adulto {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		int edad;
		
		System.out.println("Ingrese una Edad:");
		edad = tc.nextInt();
		
		while(edad <= 0) {
			System.out.println("Solo Validos los Valores Mayores a 0");
			System.out.println("Ingrese una Edad:");
			edad = tc.nextInt();
		}
		
		if(edad <= 12 && edad >= 0) {
			System.out.println("Esa Persona es un Niño");
		}else if(edad <= 25 && edad >=13) {
			System.out.println("Esa Persona es un Joven");
		}else if(edad > 25){
			System.out.println("Esa Persona es un Adulto");
		}

	}

}
