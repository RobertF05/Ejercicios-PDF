package Ejercicios_41_al_45;

import java.util.Scanner;

public class N_numeros {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		int n = 0, b = 0, num = 0, suma = 0;
		
		System.out.println("¿Cuantos Numeros va a Ingresar?");
		n = tc.nextInt();
		
		for(int i = 1; i <= n; i++) {
			System.out.println("Ingrese un numero");
			num = tc.nextInt();
			if (num > 0) {
				suma = suma + num;
			}else if(num <= 0) {
				b = b + 1;
			}			
		}
		System.out.println("El resultado de la suma es: " +suma);
		System.out.println("La cantidad de numeros negativos es: " +b);

	}

}
