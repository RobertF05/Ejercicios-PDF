package Ejercicios_41_al_45;

import java.util.Scanner;

public class Promedio_25Alumnos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		String nombre;
		int nota1 = 0, nota2 = 0, nota3 = 0;
		double prom;
		
		for(int i = 1; i<= 25; i++) {
		System.out.println("Ingrese Nombre del Alumno #" +i);
		nombre = tc.nextLine();
		System.out.println("Ingrese la Primer Nota:");
		nota1 = tc.nextInt();
		while(nota1 <= -1 || nota1 >= 101) {
			System.out.println("Solo Puede Ingresar Valores Entre el 0 y el 100");
			System.out.println("Ingrese la Primer Nota:");
			nota1 = tc.nextInt();
		}
			System.out.println("Ingrese la Segunda Nota: ");
			nota2 = tc.nextInt();
			while(nota2 <= -1 || nota2 >= 101) {
				System.out.println("Solo Puede Ingresar Valores Entre el 0 y el 100");
				System.out.println("Ingrese la Segunda Nota: ");
				nota2 = tc.nextInt();
			}
			System.out.println("Ingrese la Tercer Nota: ");
			nota3 = tc.nextInt();
			while(nota3 <= -1 || nota3 >= 101) {
					System.out.println("Solo Puede Ingresar Valores Entre el 0 y el 100");
					System.out.println("Ingrese la Tercer Nota: ");
					nota3 = tc.nextInt();
			}
					prom = (nota1 + nota2 + nota3) / 3;
					System.out.println("El Promedio de " +nombre+ " es: " +prom);
					tc.nextLine();
				}
}
}