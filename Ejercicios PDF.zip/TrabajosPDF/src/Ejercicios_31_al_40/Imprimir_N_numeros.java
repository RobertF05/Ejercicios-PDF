package Ejercicios_31_al_40;

import java.util.Scanner;

public class Imprimir_N_numeros {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		int num = 0, aum = 0;
		
		System.out.println("Ingrese la Cantidad de Numeros a Imprimir: ");
		num = tc.nextInt();
		
		for (int i = 1; i <= num; i++) {
		aum = i;
		System.out.println(aum);
		}

	}

}
