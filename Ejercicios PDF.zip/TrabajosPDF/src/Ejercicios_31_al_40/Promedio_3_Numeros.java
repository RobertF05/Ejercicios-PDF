package Ejercicios_31_al_40;

import java.util.Scanner;

public class Promedio_3_Numeros {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		int n1, n2, n3;
		double prom;
		
		System.out.println("Ingrese el Primer Valor: ");
		n1 = tc.nextInt();
		System.out.println("Ingrese el Segundo Valor: ");
		n2 = tc.nextInt();
		System.out.println("Ingrese el Tercer Valor: ");
		n3 = tc.nextInt();
		
		prom = (double) (n1 + n2 + n3) / 3;
		
		System.out.println("Su promedio es de: " +prom);

	}

}
