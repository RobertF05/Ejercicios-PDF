package Ejercicios_31_al_40;

import java.util.Scanner;

public class Promedio_N_numeros {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		int n, ni, suma = 0;
		double prom;
		
		System.out.println("¿Cuantos Valores va a Ingresar?");
		n = tc.nextInt();
		
		for(int i = 1; i <= n; i++) {
			System.out.println("Ingrese Valor #" +i);
			ni = tc.nextInt();
			suma = suma + ni;
		}
		
		prom = (double) suma / n;
		
		System.out.println("Su promedio es de: " +prom);

	}

}
