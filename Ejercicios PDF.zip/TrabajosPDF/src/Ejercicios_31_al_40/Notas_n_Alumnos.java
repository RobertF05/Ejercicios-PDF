package Ejercicios_31_al_40;

import java.util.Scanner;

public class Notas_n_Alumnos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		int n, nota;
		
		System.out.println("¿Cuantos Alumnos va a Ingresar?");
		n = tc.nextInt();
		
		for(int i = 1; i <= n; i++) {
			System.out.println("Ingrese la Nota del Alumno #" +i);
			nota = tc.nextInt();
			if(nota <= 59 && nota >= 0) {
				System.out.println("Esta Reprobado");
			}else if(nota >= 59 && nota <= 100) {
				System.out.println("Esta Aprobado");
			}else if(nota >= 101 || nota <= -1) {
				System.out.println("Valor Ingresado no Valido");
				i = i- 1;
			}
		}

	}

}
