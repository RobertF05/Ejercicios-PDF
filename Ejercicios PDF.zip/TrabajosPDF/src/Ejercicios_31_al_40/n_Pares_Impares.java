package Ejercicios_31_al_40;

import java.util.Scanner;

public class n_Pares_Impares {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		int n, v, par = 0, impar = 0;
		
		System.out.println("¿Cuatos Numeros va a Ingresar?");
		n = tc.nextInt();
		
		for(int i = 1; i <= n; i++) {
			System.out.println("Ingrese Valor #" +i);
			v = tc.nextInt();
			if (v % 2 == 0) {
				par = par + 1;
			}else if(v % 2 != 0) {
				impar = impar + 1;
			}
		}
		
		System.out.println("La Cantidad de Pares es: " +par);
		System.out.println("La Cantidad de Impares es: " +impar);

	}

}
