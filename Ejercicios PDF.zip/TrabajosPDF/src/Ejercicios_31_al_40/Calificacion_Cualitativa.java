package Ejercicios_31_al_40;

import java.util.Scanner;

public class Calificacion_Cualitativa {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		int n, p;
		
		System.out.println("¿Cuantas notas va a Ingresar?");
		n = tc.nextInt();
		
		while (n <= -1) {
			System.out.println("Ingrese Solo Numeros Positivos");
			System.out.println("¿Cuantas notas va a Ingresar?");
			n = tc.nextInt();
		}
		
		for (int i = 1; i <= n; i++) {
			System.out.println("Ingrese la Nota #" +i);
			p = tc.nextInt();
			
			if(p >= 90) {
				System.out.println("Su Calificacion Cualitativamente es A");
			}else if(p >= 80 && p < 90){
				System.out.println("Su Calificacion Cualitativamente es B");
			}else if(p >= 70 && p < 80){
				System.out.println("Su Calificacion Cualitativamente es C");
			}else if(p >= 65 && p < 70){
				System.out.println("Su Calificacion Cualitativamente es D");
			}else if(p < 65 && p >= 0){
				System.out.println("Su Calificacion Cualitativamente es E");
			}else if(p <= -1 || p >= 101) {
				System.out.println("Nota invalida");
				i = i - 1;
			}
		}

	}

}
