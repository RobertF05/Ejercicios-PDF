package Ejercicios_31_al_40;

import java.util.Scanner;

public class Factorial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		int fact;
		double r = 1;
		try {
			System.out.println("Ingrese un numero");
			fact = tc.nextInt();
			
			if(fact <= -1) {
				System.out.println("Solo se validan numeros del cero en adelante");
			}else {
				for(int i = 1; i <= fact; i++) {
					r = i * r;
				}
				System.out.println(fact+ " != " +r);
			}
		
		}catch (Exception a) {
			System.out.println("Solo se validan numeros");
		}

	}

}
