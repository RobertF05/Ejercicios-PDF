package Ejercicios_31_al_40;

import java.util.Scanner;

public class Impares_20_a_100 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		int suma = 0, i;
		
		for( i = 21; i <= 99; i++) {
			//System.out.println(i+ " ");
		suma = suma + i;
		}
			i = i - 60;
			System.out.println("La Cantidad de Impares Entre el 20 y el 100 es: " +i);
			System.out.println("La Suma de ellos es: " +suma);

	}
	
}
